# ROADMAP — Evoluções Futuras (Planejamento)

Este documento lista ideias de mecânicas para estudar e implementar **gradualmente** em etapas futuras.
**Status atual:** nenhuma dessas mecânicas foi implementada ainda — o projeto permanece fiel ao funcionamento original para servir como linha de base limpa.

---

## Fase 1 — Base de Território e Recursos

- [ ] **Recursos por território:** associar tipos de terreno (floresta, montanha, colina, planície, água) a recursos naturais disponíveis em cada hexágono.
- [ ] **Madeira:** recurso coletável em hexágonos de floresta/madeireira (`grass-forest`, `dirt-lumber`).
- [ ] **Pedra:** recurso extraído em hexágonos rochosos ou colinas (`stone`, `stone-hill`, `stone-rocks`).
- [ ] **Minério:** recurso de áreas montanhosas e minas (`stone-mountain`, `building-mine`, `building-smelter`).

## Fase 2 — População e Habitação

- [ ] **População:** contador global de habitantes com capacidade máxima e crescimento gradual.
- [ ] **Casas:** estruturas residenciais (`building-house`, `building-cabin`, `building-village`) que aumentam o limite de população.
- [ ] **Trabalhadores:** alocação de parte da população para operar construções produtivas e extrair recursos.

## Fase 3 — Economia e Automação

- [ ] **Produção automática:** ciclo periódico (timer/tick) que gera madeira, pedra, minério ou alimentos conforme construções ativas e trabalhadores alocados.
- [ ] **Dinheiro:** evolução do saldo atual (`DataMap.cash`) integrando custos reais por construção, manutenção e geração de receita (ex.: `building-market`, `building-port`).

## Fase 4 — Expansão e Progressão da Cidade

- [ ] **Expansão territorial:** sistema de fronteiras desbloqueáveis, permitindo conquistar ou comprar novos anéis/hexágonos adjacentes usando `HexCell.get_adjacent`.
- [ ] **Melhorias de construções:** sistema de níveis/upgrades para estruturas já posicionadas no mapa, aumentando eficiência ou capacidade.
- [ ] **Evolução da cidade:** marcos de progressão (acampamento → vila → cidade → cidadela/castelo) que desbloqueiam novas construções e objetivos.

---

## Diretriz de Estudo

Cada item acima deve ser desenvolvido em **uma branch ou commit dedicado**, testando no Godot a cada passo para compreender:
1. Estrutura de dados (`Resource`, `Dictionary`, `HexCell`);
2. Separação entre lógica de simulação e visualização 3D;
3. Atualização de interface (UI) via sinais (`signal`);
4. Persistência compatível com `DataMap` / `ResourceSaver`.
