# Hexagon World — Projeto de Aprendizado em Godot

Este repositório é uma **cópia independente de aprendizado** baseada no projeto open source [Starter-Kit-Hexagon-World](https://github.com/michiel-van-den-anker/Starter-Kit-Hexagon-World) (de Michiel van den Anker), que por sua vez adapta o *Starter Kit City Builder* de KenneyNL para uma grade hexagonal 3D.

O objetivo inicial deste repositório é manter a base original limpa, funcional e documentada para estudar a arquitetura de jogos no Godot Engine e evoluir novas mecânicas de forma gradual, uma por vez.

---

## Versão do Godot necessária

- **Recomendada:** **Godot 4.2** (ou 4.2.x estável) com renderizador **Forward Plus**.
  - O arquivo `project.godot` define `config_version=5` e `config/features=PackedStringArray("4.2", "Forward Plus")`.
  - Observação: o `README.md` herdado do template original do Kenney mencionava `Godot 4.1.1.stable`, mas o projeto foi salvo com recursos do Godot 4.2.

---

## Como executar o projeto

1. Instale o **Godot Engine 4.2+** (versão Standard, GDScript).
2. Clone este repositório (ou extraia os arquivos do projeto) em uma pasta local.
3. Abra o **Godot Project Manager**, clique em **Import** e selecione o arquivo `project.godot` na raiz do projeto.
4. Aguarde a importação automática dos modelos `.glb`, texturas e fontes.
5. Pressione **F5** (ou clique no botão **Play**) para executar a cena principal (`res://scenes/main.tscn`).

### Controles padrão (preservados do projeto original)

| Tecla / Mouse | Ação |
| --- | --- |
| `W` `A` `S` `D` | Mover a câmera |
| `F` | Centralizar a câmera na origem |
| Botão do meio do mouse (segurar + mover) | Rotacionar a câmera |
| Botão esquerdo do mouse | Posicionar hexágono / construção |
| Botão direito do mouse | Rotacionar a peça selecionada em 60° |
| `Q` / `E` (ou roda do mouse) | Alternar entre os 72 hexágonos disponíveis |
| `DEL` | Ação `demolish` mapeada no projeto original |
| `F1` | Salvar mapa em `user://map.res` |
| `F2` | Carregar mapa de `user://map.res` |

---

## Estrutura básica dos principais arquivos

```text
.
├── project.godot                   # Configuração principal (Godot 4.2, Input Map, main_scene)
├── scenes/
│   ├── main.tscn                   # Cena principal (Builder, Selector, View/Camera, UI, Hexagons)
│   └── main-environment.tres       # Ambiente 3D, iluminação e céu
├── scripts/
│   ├── builder.gd                  # Controle central: seleção, construção, rotação, dinheiro e save/load
│   ├── view.gd                     # Controle suave da câmera (movimento WASD, rotação e centralização)
│   ├── hexagon.gd                  # Resource customizado (class_name Hexagon: model e price)
│   ├── data_map.gd                 # Resource de dados do mapa salvo (cash e array de structures)
│   ├── data_structure.gd           # Resource de cada peça salva (position, orientation, structure)
│   └── godot-gdhexgrid/
│       ├── HexGrid.gd              # Conversão entre coordenadas do mundo 3D e grade hexagonal
│       └── HexCell.gd              # Representação de célula hexagonal (cube, axial e offset coords)
├── hexagons/                       # 72 arquivos .tres definindo prédios, terrenos, rios, caminhos e unidades
├── models/Hexagons/                # Modelos 3D (.glb) e textura compartilhada (Textures/colormap.png)
├── sprites/                        # Ícones 2D da interface (coin.png e selector.png)
├── fonts/                          # Fonte da interface (lilita_one_regular.ttf)
├── sample map/map.res              # Exemplo de mapa salvo
├── README.md                       # Este guia inicial
└── ROADMAP.md                      # Planejamento de futuras evoluções (ainda não implementadas)
```

---

## Licenças e Créditos

- Base hexagonal: [michiel-van-den-anker/Starter-Kit-Hexagon-World](https://github.com/michiel-van-den-anker/Starter-Kit-Hexagon-World)
- Template original e assets 3D/2D (CC0): [KenneyNL](https://kenney.nl/) (código sob licença MIT, veja `LICENSE.md`).
- Biblioteca de grade hexagonal: `godot-gdhexgrid` (veja `scripts/godot-gdhexgrid/LICENSE.txt`).
